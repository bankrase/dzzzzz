
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		frame_2
	 *	@date 		Tuesday 18th of June 2024 02:26:43 AM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class frame_2_activity extends Activity {

	
	private View _bg__frame_2;
	private ImageView rectangle_11;
	private View rectangle_1;
	private ImageView vector;
	private TextView september_6__2022;
	private View rectangle_10;
	private ImageView rectangle_6;
	private View rectangle_7;
	private TextView android_14_will_have_native_support_to_satellite_connection_;
	private View rectangle_12;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.frame_2);

		
		_bg__frame_2 = (View) findViewById(R.id._bg__frame_2);
		rectangle_11 = (ImageView) findViewById(R.id.rectangle_11);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);
		vector = (ImageView) findViewById(R.id.vector);
		september_6__2022 = (TextView) findViewById(R.id.september_6__2022);
		rectangle_10 = (View) findViewById(R.id.rectangle_10);
		rectangle_6 = (ImageView) findViewById(R.id.rectangle_6);
		rectangle_7 = (View) findViewById(R.id.rectangle_7);
		android_14_will_have_native_support_to_satellite_connection_ = (TextView) findViewById(R.id.android_14_will_have_native_support_to_satellite_connection_);
		rectangle_12 = (View) findViewById(R.id.rectangle_12);
	
		
		//custom code goes here
	
	}
}
	
	